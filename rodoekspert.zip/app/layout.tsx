import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin", "latin-ext"] })

export const metadata: Metadata = {
  title: 'Biuro Doradczo-Usługowe "OIN" - Profesjonalne wdrażanie RODO dla firm',
  description:
    "Kompleksowe wdrożenie RODO, audyty, szkolenia i outsourcing IOD. Ponad 20 lat doświadczenia w ochronie danych osobowych.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pl" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "ProfessionalService",
              name: "Biuro Doradczo-Usługowe OIN",
              description: "Profesjonalne wdrażanie RODO dla firm",
              address: {
                "@type": "PostalAddress",
                streetAddress: "ul. Bezpieczna 123",
                addressLocality: "Warszawa",
                postalCode: "00-001",
                addressCountry: "PL",
              },
              telephone: "+48 123 456 789",
              email: "kontakt@rodoekspert.pl",
              url: "https://www.rodoekspert.pl",
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
