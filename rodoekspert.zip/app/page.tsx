import Header from "@/components/header"
import Hero from "@/components/hero"
import About from "@/components/about"
import Services from "@/components/services"
import WorkProcess from "@/components/work-process"
import CompanyStats from "@/components/company-stats"
import Team from "@/components/team"
import Faq from "@/components/faq"
import Contact from "@/components/contact"
import WhistleblowerSystem from "@/components/whistleblower-system"
import Newsletter from "@/components/newsletter"
import Footer from "@/components/footer"
import WhyUs from "@/components/why-us"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50">
      <Header />
      <Hero />
      <About />
      <Services />
      <WorkProcess />
      <WhyUs />
      <CompanyStats />
      <Team />
      <Faq />
      <Contact />
      <WhistleblowerSystem />
      <Newsletter />
      <Footer />
    </main>
  )
}
