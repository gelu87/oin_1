"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function Newsletter() {
  const [email, setEmail] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Newsletter subscription:", email)
    // Here you would typically send the data to your backend
    setEmail("")
  }

  return (
    <section className="py-16 bg-blue-50 relative">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold text-blue-800 mb-8">
          Dołącz do naszego newslettera i bądź na bieżąco ze zmianami w RODO
        </h2>
        <form className="max-w-md mx-auto flex" onSubmit={handleSubmit}>
          <Input
            type="email"
            placeholder="Twój adres e-mail"
            className="rounded-r-none shadow-sm"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button
            type="submit"
            className="rounded-l-none bg-blue-800 hover:bg-blue-700 shadow-md hover:shadow-lg transition-shadow duration-300"
          >
            Zapisz się
          </Button>
        </form>
      </div>
      <div className="section-divider-strong"></div>
    </section>
  )
}
