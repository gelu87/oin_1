import { Shield, Bell, Lock, Users } from "lucide-react"
import Link from "next/link"

export default function WhistleblowerSystem() {
  return (
    <section className="py-24 bg-gray-50 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">System Obsługi Sygnalistów</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Kompleksowe rozwiązanie zapewniające zgodność z przepisami o ochronie sygnalistów, umożliwiające bezpieczne
            zgłaszanie nieprawidłowości w organizacji.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Card 1 */}
          <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <div className="text-blue-800 mr-4">
                <Shield className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Zgodność z przepisami</h3>
            </div>
            <p className="text-gray-600">
              Pełna zgodność z Dyrektywą UE 2019/1937 o ochronie sygnalistów i polską ustawą implementującą.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <div className="text-blue-800 mr-4">
                <Bell className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Bezpieczne zgłaszanie naruszeń</h3>
            </div>
            <p className="text-gray-600">
              Poufne i bezpieczne kanały zgłaszania nieprawidłowości, zgodne z wymogami prawnymi.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <div className="text-blue-800 mr-4">
                <Lock className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Ochrona danych</h3>
            </div>
            <p className="text-gray-600">
              Pełna ochrona danych osobowych sygnalistów oraz informacji zawartych w zgłoszeniach.
            </p>
          </div>

          {/* Card 4 */}
          <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="flex items-center mb-4">
              <div className="text-blue-800 mr-4">
                <Users className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-blue-800">Profesjonalna obsługa</h3>
            </div>
            <p className="text-gray-600">
              Kompleksowa obsługa procesu zgłoszeń oraz wsparcie prawne dla organizacji i sygnalistów.
            </p>
          </div>
        </div>

        {/* Legal requirements */}
        <div className="bg-blue-50 p-8 rounded-lg mb-10 shadow-sm">
          <h3 className="text-2xl font-bold text-blue-800 text-center mb-6">Wymogi prawne</h3>
          <p className="text-gray-600 text-center">
            Zgodnie z Dyrektywą UE 2019/1937 oraz polską ustawą o ochronie sygnalistów, organizacje zatrudniające co
            najmniej 50 pracowników mają obowiązek wdrożenia wewnętrznych procedur zgłaszania nieprawidłowości oraz
            ochrony sygnalistów. Nasz system zapewnia pełną zgodność z tymi wymogami.
          </p>
        </div>

        <div className="text-center">
          <Link
            href="https://sygnalistainfo.pl/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-blue-800 text-white px-8 py-4 rounded-md font-semibold hover:bg-blue-700 transition-colors duration-300 shadow-md hover:shadow-lg transition-shadow duration-300"
          >
            Dowiedz się więcej o systemie dla sygnalistów
          </Link>
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
