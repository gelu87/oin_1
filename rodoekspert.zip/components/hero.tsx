"use client"

import { useEffect, useState } from "react"
import Link from "next/link"

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section
      id="home"
      className="hero bg-cover bg-center h-screen flex items-center relative"
      style={{ backgroundImage: `url('/hero_section.jpg')` }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-30"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div
          className={`max-w-3xl transition-all duration-1000 transform ${
            isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
          }`}
        >
          <>
            <h1 className="text-white mb-4 font-bold text-shadow-sm">
              Bezpieczeństwo danych to podstawa Twojego biznesu
            </h1>
            <h2 className="text-white mb-8 font-normal text-shadow-sm">Ty rozwijasz swój biznes, a my wdrażamy RODO</h2>
            <div
              className={`transition-all duration-1000 delay-300 transform ${
                isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
              }`}
            >
              <Link href="#contact" className="btn-primary inline-block">
                Zabezpiecz swoje dane
              </Link>
              <Link href="#services" className="btn-secondary inline-block ml-4">
                Poznaj nasze usługi
              </Link>
            </div>
          </>
        </div>
      </div>
    </section>
  )
}
