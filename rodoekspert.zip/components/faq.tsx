"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

interface FaqItem {
  question: string
  answer: string
}

export default function Faq() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqItems: FaqItem[] = [
    {
      question: "Jakie kary grożą za nieprzestrzeganie RODO?",
      answer:
        "Kary mogą wynieść nawet do 20 mln euro lub 4% całkowitego rocznego obrotu przedsiębiorstwa, w zależności od tego, która kwota jest wyższa. Dodatkowo, osoby poszkodowane mogą dochodzić odszkodowania na drodze cywilnej.",
    },
    {
      question: "Czy każda firma musi wyznaczyć Inspektora Ochrony Danych?",
      answer:
        "Nie każda. Obowiązek wyznaczenia IOD dotyczy organów publicznych, firm, których główna działalność polega na regularnym monitorowaniu osób na dużą skalę oraz firm przetwarzających na dużą skalę szczególne kategorie danych. Nasi eksperci pomogą określić, czy w Twojej organizacji istnieje taki obowiązek.",
    },
    {
      question: "Jak przygotować się do kontroli UODO?",
      answer:
        "Podstawą jest kompletna dokumentacja RODO, aktualne rejestry czynności przetwarzania, umowy powierzenia oraz przeszkoleni pracownicy. Nasz zespół pomaga przygotować organizację do kontroli i może uczestniczyć w niej jako wsparcie.",
    },
    {
      question: "Jak często należy aktualizować dokumentację RODO?",
      answer:
        "Dokumentację RODO należy aktualizować przy każdej istotnej zmianie w procesach przetwarzania danych, wprowadzeniu nowych systemów IT, zmianie dostawców usług czy zmianie przepisów. Zalecamy również regularny przegląd dokumentacji co najmniej raz w roku.",
    },
    {
      question: "Czy małe firmy też muszą stosować się do RODO?",
      answer:
        "Tak, RODO dotyczy wszystkich podmiotów przetwarzających dane osobowe, niezależnie od wielkości. Jednak zakres obowiązków może być różny - np. małe firmy mogą być zwolnione z obowiązku prowadzenia rejestru czynności przetwarzania, jeśli spełniają określone warunki.",
    },
  ]

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="py-16 bg-gray-50 relative">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-blue-800 text-center mb-10">Najczęściej zadawane pytania</h2>

        <div className="max-w-3xl mx-auto">
          {faqItems.map((item, index) => (
            <div key={index} className="mb-4 border border-gray-200 rounded-lg overflow-hidden">
              <button
                className="w-full text-left p-4 bg-white flex justify-between items-center hover:bg-gray-50 transition-colors"
                onClick={() => toggleItem(index)}
                aria-expanded={openIndex === index}
                aria-controls={`faq-answer-${index}`}
              >
                <h3 className="text-lg font-semibold">{item.question}</h3>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-blue-600" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-blue-600" />
                )}
              </button>

              <div
                id={`faq-answer-${index}`}
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                }`}
              >
                <p className="p-4 bg-gray-50 text-gray-700">{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
