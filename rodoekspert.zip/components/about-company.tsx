import Link from "next/link"

export default function AboutCompany() {
  return (
    <section className="highlight py-20 relative">
      <div className="container mx-auto px-6">
        {/* Quote at the top */}
        <div className="text-center mb-16">
          <svg className="w-12 h-12 mx-auto mb-4 text-blue-300" fill="currentColor" viewBox="0 0 24 24">
            <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
          </svg>
          <p className="text-2xl italic text-white font-light">"RODO to dla nas chleb powszedni"</p>
        </div>

        <div className="flex flex-col md:flex-row items-center">
          {/* Text column */}
          <div className="md:w-1/2 md:pr-12 pb-10 md:pb-0">
            <p className="text-lg mb-6">
              Pomagamy firmom chronić dane od ponad 20 lat. Rozumiemy, że każdy biznes jest wyjątkowy, dlatego oferujemy
              rozwiązania dopasowane dokładnie do Twoich potrzeb.
            </p>
            <p className="text-lg mb-6">
              Nasi eksperci łączą doświadczenie z praktycznym podejściem. Nie komplikujemy - tłumaczymy RODO prostym
              językiem i wdrażamy je tak, by wspierało Twój biznes, a nie utrudniało pracę.
            </p>
            <p className="text-lg">
              <strong>Dlaczego warto powierzyć sprawy RODO profesjonalistom?</strong> Powierzenie spraw RODO firmie
              zewnętrznej to nie tylko oszczędność czasu, ale przede wszystkim gwarancja profesjonalizmu. Zamiast
              szkolić własnych pracowników i tworzyć nowe etaty, zyskujesz dostęp do specjalistów z wieloletnim
              doświadczeniem. Outsourcing IOD pozwala Ci skupić się na kluczowych obszarach Twojej działalności, podczas
              gdy eksperci dbają o zgodność z przepisami i bezpieczeństwo danych Twoich klientów. W przypadku kontroli
              UODO masz pewność, że wszystkie dokumenty i procedury są poprawnie wdrożone, a Ty możesz spać spokojnie.
            </p>
          </div>

          {/* Dividing line */}
          <div className="hidden md:block w-px bg-blue-400 self-stretch mx-8"></div>

          {/* Stats column */}
          <div className="md:w-1/2 space-y-6 flex flex-col justify-between">
            <div className="flex items-center">
              <div className="bg-white text-blue-800 rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mr-4 shadow-md">
                22
              </div>
              <div className="text-lg">lata doświadczenia w ochronie informacji</div>
            </div>
            <div className="flex items-center">
              <div className="bg-white text-blue-800 rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mr-4 shadow-md">
                9
              </div>
              <div className="text-lg">lat na rynku</div>
            </div>
            <div className="flex items-center">
              <div className="bg-white text-blue-800 rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mr-4 shadow-md">
                100+
              </div>
              <div className="text-lg">obsługiwanych organizacji</div>
            </div>
            <div className="flex items-center">
              <div className="bg-white text-blue-800 rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mr-4 shadow-md">
                300+
              </div>
              <div className="text-lg">zrealizowanych szkoleń</div>
            </div>
            <div className="flex items-center">
              <div className="bg-white text-blue-800 rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mr-4 shadow-md">
                30+
              </div>
              <div className="text-lg">przeprowadzonych audytów</div>
            </div>
          </div>
        </div>

        {/* CTA to contact form */}
        <div className="text-center mt-16">
          <Link
            href="#contact"
            className="bg-white text-blue-800 px-8 py-3 rounded-md font-semibold hover:bg-blue-100 transition-colors duration-300 inline-block shadow-md hover:shadow-lg transition-shadow duration-300"
          >
            Skontaktuj się z nami
          </Link>
        </div>
      </div>
      <div className="section-divider-shadow"></div>
    </section>
  )
}
