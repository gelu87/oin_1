import Link from "next/link"
import { CheckCircle } from "lucide-react"

export default function CompanyStats() {
  return (
    <section className="py-20 bg-gradient-to-r from-blue-800 to-blue-700 text-white relative border-b border-gray-300">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-white text-3xl font-bold mb-8 text-center text-shadow-sm">
            Dlaczego warto powierzyć nam RODO?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {/* Lewa kolumna - korzyści */}
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-white text-xl font-bold mb-4">Oszczędzasz czas i zasoby</h3>
              <p className="text-white mb-6">
                Powierzenie spraw RODO firmie zewnętrznej to oszczędność czasu i gwarancja profesjonalizmu. Zamiast
                szkolić własnych pracowników, zyskujesz dostęp do specjalistów z wieloletnim doświadczeniem.
              </p>
              <ul className="text-white space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-300 mr-2 mt-1 flex-shrink-0" />
                  <span>Skupiasz się na kluczowych obszarach swojej działalności</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-300 mr-2 mt-1 flex-shrink-0" />
                  <span>Masz pewność zgodności z przepisami podczas kontroli UODO</span>
                </li>
              </ul>
            </div>

            {/* Prawa kolumna - osiągnięcia */}
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-white text-xl font-bold mb-4">Nasze doświadczenie w liczbach</h3>

              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-white/20 text-white text-xl font-bold h-16 w-16 rounded-lg flex items-center justify-center mr-4">
                    22
                  </div>
                  <p className="text-white">lata doświadczenia w ochronie informacji</p>
                </div>

                <div className="flex items-center">
                  <div className="bg-white/20 text-white text-xl font-bold h-16 w-16 rounded-lg flex items-center justify-center mr-4">
                    100+
                  </div>
                  <p className="text-white">obsługiwanych organizacji różnej wielkości</p>
                </div>

                <div className="flex items-center">
                  <div className="bg-white/20 text-white text-xl font-bold h-16 w-16 rounded-lg flex items-center justify-center mr-4">
                    30+
                  </div>
                  <p className="text-white">przeprowadzonych audytów bezpieczeństwa</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-16">
            <Link
              href="#contact"
              className="bg-white text-blue-800 px-8 py-3 rounded-md font-semibold hover:bg-blue-100 transition-colors duration-300 shadow-md hover:shadow-lg hover-lift"
            >
              Skontaktuj się z nami
            </Link>
          </div>
        </div>
      </div>
      <div className="section-divider-shadow"></div>
    </section>
  )
}
