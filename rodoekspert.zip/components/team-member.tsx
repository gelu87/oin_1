import Image from "next/image"

interface TeamMemberProps {
  name: string
  role: string
  imageUrl: string
}

export function TeamMember({ name, role, imageUrl }: TeamMemberProps) {
  return (
    <div className="text-center group">
      <div className="w-40 h-40 rounded-full overflow-hidden mx-auto mb-6 relative shadow-md group-hover:shadow-lg transition-shadow duration-300">
        <Image src={imageUrl || "/placeholder.svg"} alt={name} fill className="object-cover" />
      </div>
      <h3 className="text-xl font-bold">{name}</h3>
      <p className="text-gray-600">{role}</p>
    </div>
  )
}
