"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [activeSection, setActiveSection] = useState("home")

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }

      // Determine active section based on scroll position
      const sections = ["home", "about", "services", "contact"]
      for (const section of sections.reverse()) {
        const element = document.getElementById(section)
        if (element && window.scrollY >= element.offsetTop - 100) {
          setActiveSection(section)
          break
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? "bg-white shadow-md py-2" : "bg-white/95 py-3"
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center">
          <Image src="/oin_logo.png" alt="OIN Logo" width={48} height={48} className="mr-3" />
          <span className="text-2xl font-bold text-blue-800">Biuro Doradczo-Usługowe "OIN"</span>
        </div>

        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li>
              <Link
                href="#"
                className={`py-2 font-semibold transition-colors duration-300 ${
                  activeSection === "home"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-800 hover:text-blue-600"
                }`}
              >
                Strona główna
              </Link>
            </li>
            <li>
              <Link
                href="#about"
                className={`py-2 font-semibold transition-colors duration-300 ${
                  activeSection === "about"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-800 hover:text-blue-600"
                }`}
              >
                O nas
              </Link>
            </li>
            <li>
              <Link
                href="#services"
                className={`py-2 font-semibold transition-colors duration-300 ${
                  activeSection === "services"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-800 hover:text-blue-600"
                }`}
              >
                Usługi
              </Link>
            </li>
            <li>
              <Link
                href="#contact"
                className={`py-2 font-semibold transition-colors duration-300 ${
                  activeSection === "contact"
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-800 hover:text-blue-600"
                }`}
              >
                Kontakt
              </Link>
            </li>
          </ul>
        </nav>

        <button
          className="md:hidden text-2xl"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
          aria-expanded={isMenuOpen}
        >
          {isMenuOpen ? <X /> : <Menu />}
        </button>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-lg z-50">
            <ul className="flex flex-col p-4">
              <li>
                <Link
                  href="#"
                  className={`block py-3 font-semibold ${activeSection === "home" ? "text-blue-600" : "text-gray-800"}`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Strona główna
                </Link>
              </li>
              <li>
                <Link
                  href="#about"
                  className={`block py-3 font-semibold ${
                    activeSection === "about" ? "text-blue-600" : "text-gray-800"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  O nas
                </Link>
              </li>
              <li>
                <Link
                  href="#services"
                  className={`block py-3 font-semibold ${
                    activeSection === "services" ? "text-blue-600" : "text-gray-800"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Usługi
                </Link>
              </li>
              <li>
                <Link
                  href="#contact"
                  className={`block py-3 font-semibold ${
                    activeSection === "contact" ? "text-blue-600" : "text-gray-800"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Kontakt
                </Link>
              </li>
            </ul>
          </div>
        )}
      </div>
    </header>
  )
}
