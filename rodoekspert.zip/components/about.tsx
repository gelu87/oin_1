import Link from "next/link"
import Image from "next/image"
import { CheckCircle } from "lucide-react"

export default function About() {
  return (
    <section id="about" className="bg-gradient-to-r from-blue-900 to-blue-800 py-16 relative border-b border-gray-300">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Kolumna z tekstem - 7/12 szerokości na desktop */}
          <div className="md:col-span-7">
            <h2 className="text-white text-3xl font-bold mb-6 text-shadow-sm">
              Profesjonalna ochrona danych dla Twojego biznesu
            </h2>

             <div className="glass-effect p-6 rounded-lg mb-6">
        <p className="text-white text-lg mb-4">
          Od ponad 20 lat pomagamy firmom chronić dane osobowe i wdrażać efektywne procedury zgodne z RODO. Nasze
          doświadczenie pozwala na szybkie identyfikowanie ryzyka i wdrażanie skutecznych zabezpieczeń.
        </p>
        <p className="text-white text-lg">
          Nasza firma specjalizuje się również w świadczeniu usługi Inspektora Ochrony Danych dla firm i organizacji.
        </p>
            </div>

            <ul className="text-white space-y-3">
              <li className="flex items-start">
                <CheckCircle className="h-6 w-6 text-blue-300 mr-2 mt-1 flex-shrink-0" />
                <span>Skuteczne szkolenia pracowników z zakresu RODO</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-6 w-6 text-blue-300 mr-2 mt-1 flex-shrink-0" />
                <span>Kompleksowe wdrożenia i audyty bezpieczeństwa</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-6 w-6 text-blue-300 mr-2 mt-1 flex-shrink-0" />
                <span>Wsparcie w kontaktach z UODO i podczas kontroli</span>
              </li>
            </ul>
          </div>

          {/* Kolumna z grafiką/ilustracją - 5/12 szerokości na desktop */}
          <div className="md:col-span-5 hidden md:block">
            <div className="glass-effect p-8 rounded-lg">
              <div className="relative w-full h-64">
                <Image
                  src="/about_section.jpg"
                  alt="Profesjonalna ochrona danych"
                  className="rounded shadow-lg object-cover"
                  fill
                />
              </div>
              <div className="mt-6 text-center">
                <Link
                  href="#contact"
                  className="inline-block px-6 py-3 bg-white text-blue-800 font-semibold rounded-md shadow-lg hover:bg-blue-50 transition-all duration-300 transform hover:-translate-y-1"
                >
                  Skontaktuj się z nami
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Przycisk CTA widoczny tylko na mobile */}
        <div className="mt-8 text-center md:hidden">
          <Link
            href="#contact"
            className="inline-block px-6 py-3 bg-white text-blue-800 font-semibold rounded-md shadow-lg hover:bg-blue-50 transition-all duration-300"
          >
            Skontaktuj się z nami
          </Link>
        </div>
      </div>
      <div className="section-divider-shadow"></div>
    </section>
  )
}
