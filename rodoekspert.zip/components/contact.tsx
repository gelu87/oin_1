"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock } from "lucide-react"

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
    consent: false,
  })

  const [formState, setFormState] = useState<"idle" | "submitting" | "success" | "error">("idle")
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) {
      newErrors.name = "Imię jest wymagane"
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email jest wymagany"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Podaj poprawny adres email"
    }

    if (!formData.phone.trim()) {
      newErrors.phone = "Telefon jest wymagany"
    }

    if (!formData.service) {
      newErrors.service = "Wybierz interesującą Cię usługę"
    }

    if (!formData.consent) {
      newErrors.consent = "Zgoda jest wymagana"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setFormState("submitting")

    // Simulate API call
    setTimeout(() => {
      console.log("Form submitted:", formData)
      setFormState("success")
      // Reset form after successful submission
      setFormData({
        name: "",
        email: "",
        phone: "",
        service: "",
        message: "",
        consent: false,
      })
    }, 1500)
  }

  return (
    <section id="contact" className="py-20 bg-gray-100 relative">
      <div className="container mx-auto px-6">
        <div className="bg-white rounded-lg shadow-xl overflow-hidden">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/2 p-10">
              <h2 className="text-3xl font-bold text-blue-800 mb-4">Zweryfikuj zgodność z RODO</h2>
              <p className="mb-6">
                Skontaktuj się z nami, aby otrzymać bezpłatną wstępną analizę potrzeb Twojej organizacji w zakresie
                ochrony danych osobowych.
              </p>

              <div className="bg-blue-50 p-4 rounded-lg mb-6 flex items-start">
                <Clock className="text-blue-600 mr-3 mt-1 flex-shrink-0" />
                <p className="text-sm">
                  <span className="font-semibold">Szybka odpowiedź:</span> Odpowiadamy na wszystkie zapytania w ciągu 24
                  godzin roboczych.
                </p>
              </div>

              <h3 className="text-xl font-bold mb-3">Co zyskujesz?</h3>
              <ul className="list-disc pl-5 mb-6 space-y-2">
                <li>Bezpłatną wstępną analizę potrzeb</li>
                <li>Indywidualne podejście i rozwiązania</li>
                <li>Konkretne propozycje działań</li>
                <li>Oszczędność czasu</li>
                <li>Spokój i pewność zgodności z przepisami</li>
              </ul>
            </div>

            <div className="md:w-1/2 bg-blue-50 p-10">
              {formState === "success" ? (
                <div className="text-center py-10">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg
                      className="w-8 h-8 text-green-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-blue-800 mb-2">Dziękujemy za wiadomość!</h3>
                  <p className="text-gray-600 mb-6">Odpowiemy na Twoje zapytanie w ciągu 24 godzin roboczych.</p>
                  <Button onClick={() => setFormState("idle")} className="bg-blue-600 hover:bg-blue-700">
                    Wyślij nowe zapytanie
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Imię i nazwisko*</Label>
                      <Input
                        id="name"
                        placeholder="Twoje imię i nazwisko"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={`shadow-sm ${errors.name ? "border-red-500" : ""}`}
                      />
                      {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email*</Label>
                      <Input
                        type="email"
                        id="email"
                        placeholder="twoj@email.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className={`shadow-sm ${errors.email ? "border-red-500" : ""}`}
                      />
                      {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefon*</Label>
                      <Input
                        id="phone"
                        placeholder="Numer telefonu"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className={`shadow-sm ${errors.phone ? "border-red-500" : ""}`}
                      />
                      {errors.phone && <p className="text-red-500 text-sm">{errors.phone}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="service">Interesuje mnie*</Label>
                      <Select
                        onValueChange={(value) => setFormData({ ...formData, service: value })}
                        value={formData.service}
                      >
                        <SelectTrigger id="service" className={`shadow-sm ${errors.service ? "border-red-500" : ""}`}>
                          <SelectValue placeholder="Wybierz usługę" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="audyt">Audyt RODO</SelectItem>
                          <SelectItem value="szkolenia">Szkolenia z RODO</SelectItem>
                          <SelectItem value="wdrozenie">Wdrożenie RODO</SelectItem>
                          <SelectItem value="konsultacje">Konsultacje</SelectItem>
                          <SelectItem value="iod">Outsourcing IOD</SelectItem>
                          <SelectItem value="uodo">Relacje z UODO</SelectItem>
                        </SelectContent>
                      </Select>
                      {errors.service && <p className="text-red-500 text-sm">{errors.service}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Wiadomość (opcjonalnie)</Label>
                      <Textarea
                        id="message"
                        rows={3}
                        placeholder="Opisz swoje potrzeby lub zadaj pytanie"
                        className="resize-none shadow-sm"
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      />
                    </div>

                    <div className="flex items-start space-x-2">
                      <Checkbox
                        id="consent"
                        checked={formData.consent}
                        onCheckedChange={(checked) => setFormData({ ...formData, consent: checked as boolean })}
                        className={errors.consent ? "border-red-500" : ""}
                      />
                      <Label htmlFor="consent" className="text-sm text-gray-600">
                        Wyrażam zgodę na przetwarzanie moich danych osobowych zgodnie z polityką prywatności w celu
                        udzielenia odpowiedzi na zapytanie.*
                      </Label>
                    </div>
                    {errors.consent && <p className="text-red-500 text-sm">{errors.consent}</p>}

                    <Button
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700 shadow-md hover:shadow-lg transition-shadow duration-300 mt-4"
                      disabled={formState === "submitting"}
                    >
                      {formState === "submitting" ? "Wysyłanie..." : "Otrzymaj bezpłatną analizę"}
                    </Button>

                    <p className="text-sm text-gray-500 text-center mt-2">* Pola wymagane</p>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
