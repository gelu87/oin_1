import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

interface ServiceCardProps {
  title: string
  description: string
  imageUrl: string
}

export function ServiceCard({ title, description, imageUrl }: ServiceCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden service-card flex flex-col h-full">
      <div className="h-48 bg-gray-200 relative overflow-hidden">
        <Image
          src={imageUrl || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform duration-500 hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          loading="lazy"
        />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-blue-800 mb-3">{title}</h3>
        <p className="mb-6 flex-grow text-gray-700">{description}</p>
        <div className="mt-auto">
          <Link
            href="#contact"
            className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-800 transition-colors group"
          >
            Zabezpiecz swój biznes
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </div>
  )
}
