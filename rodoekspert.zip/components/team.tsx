import { TeamMember } from "./team-member"

export default function Team() {
  const team = [
    {
      id: 1,
      name: "Anna Kowalska",
      role: "Główny specjalista ds. RODO",
      image: "/professional-woman-diverse.png",
    },
    {
      id: 2,
      name: "Jan Nowak",
      role: "Inspektor Ochrony Danych",
      image: "/professional-man.png",
    },
    {
      id: 3,
      name: "Marta Wiśniewska",
      role: "Audytor RODO",
      image: "/placeholder.svg?key=idz7h",
    },
    {
      id: 4,
      name: "Piotr Kowalczyk",
      role: "Trener i konsultant",
      image: "/professional-man-consultant.png",
    },
    {
      id: 5,
      name: "Katarzyna Nowakowska",
      role: "Specjalista ds. szkoleń",
      image: "/placeholder.svg?key=ha2id",
    },
  ]

  return (
    <section className="py-20 bg-gray-50 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">Nasz zespół</h2>
          <p className="text-lg max-w-2xl mx-auto">
            Nasz zespół specjalistów jest gotów na każde wyzwanie w dziedzinie Ochrony Danych
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
          {team.map((member) => (
            <TeamMember key={member.id} name={member.name} role={member.role} imageUrl={member.image} />
          ))}
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
