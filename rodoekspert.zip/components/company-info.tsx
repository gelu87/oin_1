import { StatCard } from "./stat-card"

export default function CompanyInfo() {
  return (
    <section className="py-20 bg-blue-800 text-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center mb-16">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <p className="mb-4">
              Jesteśmy zespołem ekspertów z bogatym doświadczeniem w dziedzinie ochrony danych osobowych. Od ponad dwóch
              dekad pomagamy firmom i instytucjom w dostosowaniu ich działalności do wymogów prawnych. Nasza wiedza i
              doświadczenie pozwalają nam świadczyć usługi na najwyższym poziomie, niezależnie od wielkości i branży
              klienta.
            </p>
            <p>
              Specjalizujemy się w kompleksowym wdrażaniu RODO, przeprowadzaniu profesjonalnych audytów oraz szkoleniach
              pracowników z zakresu ochrony danych osobowych. Współpracujemy zarówno z małymi przedsiębiorstwami, jak i
              dużymi korporacjami, dopasowując nasze rozwiązania do indywidualnych potrzeb każdego klienta.
            </p>
          </div>
          <div className="md:w-1/2 space-y-6">
            <StatCard number="22" text="lata doświadczenia w ochronie informacji" />
            <StatCard number="9" text="lat na rynku" />
            <StatCard number="100+" text="obsługiwanych organizacji" />
          </div>
        </div>

        <div className="flex flex-col md:flex-row-reverse items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pl-10">
            <p className="mb-4">
              Nasz zespół tworzą osoby z wieloletnim doświadczeniem w dziedzinie prawa ochrony danych osobowych.
              Śledzimy na bieżąco wszystkie zmiany w przepisach, dzięki czemu zapewniamy naszym klientom aktualne i
              zgodne z prawem rozwiązania.
            </p>
            <p>
              Nasze podejście opiera się na indywidualnym traktowaniu każdego klienta. Nie stosujemy gotowych szablonów
              - każdy projekt traktujemy jako nowe wyzwanie, wymagające unikalnego podejścia i rozwiązań dostosowanych
              do specyfiki biznesu klienta.
            </p>
          </div>
          <div className="md:w-1/2 space-y-6">
            <StatCard number="300+" text="zrealizowanych szkoleń" />
            <StatCard number="30+" text="przeprowadzonych audytów" />
          </div>
        </div>

        <div className="text-center mt-16 text-2xl italic">"RODO to dla nas chleb powszedni"</div>
      </div>
    </section>
  )
}
