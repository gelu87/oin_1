interface StatCardProps {
  number: string
  text: string
}

export function StatCard({ number, text }: StatCardProps) {
  return (
    <div className="flex items-center">
      <div className="bg-white text-blue-800 rounded-full w-24 h-24 flex items-center justify-center text-4xl font-bold mr-6">
        {number}
      </div>
      <div className="text-xl">{text}</div>
    </div>
  )
}
