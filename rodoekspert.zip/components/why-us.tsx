import { Award, Users, Clock } from "lucide-react"

export default function WhyUs() {
  return (
    <section className="py-16 bg-white relative">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-blue-800 text-center mb-12">Dlaczego warto nam zaufać?</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="inline-block p-4 bg-blue-100 rounded-full mb-4">
              <Clock className="w-10 h-10 text-blue-800" />
            </div>
            <h3 className="text-xl font-bold mb-3">Ponad 20 lat doświadczenia</h3>
            <p className="text-gray-600">
              Zajmujemy się ochroną danych od 2001 roku, na długo przed wprowadzeniem RODO.
            </p>
          </div>

          <div className="text-center">
            <div className="inline-block p-4 bg-blue-100 rounded-full mb-4">
              <Users className="w-10 h-10 text-blue-800" />
            </div>
            <h3 className="text-xl font-bold mb-3">Indywidualne podejście</h3>
            <p className="text-gray-600">
              Nie korzystamy z szablonów - każde rozwiązanie dopasowujemy do specyfiki Twojej firmy.
            </p>
          </div>

          <div className="text-center">
            <div className="inline-block p-4 bg-blue-100 rounded-full mb-4">
              <Award className="w-10 h-10 text-blue-800" />
            </div>
            <h3 className="text-xl font-bold mb-3">Ciągłe wsparcie</h3>
            <p className="text-gray-600">Zapewniamy wsparcie na każdym etapie wdrożenia i po jego zakończeniu.</p>
          </div>
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
