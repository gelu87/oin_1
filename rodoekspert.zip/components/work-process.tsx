import { CheckCircle } from "lucide-react"

export default function WorkProcess() {
  const steps = [
    {
      number: 1,
      title: "Analiza wstępna",
      description:
        "Oceniamy aktualny stan organizacji w kontekście ochrony danych oraz identyfikujemy kluczowe obszary wymagające dostosowania.",
    },
    {
      number: 2,
      title: "Plan działania",
      description:
        "Opracowujemy szczegółowy plan wdrożenia lub optymalizacji procesów związanych z ochroną danych, dostosowany do specyfiki organizacji.",
    },
    {
      number: 3,
      title: "Implementacja",
      description: "Wdrażamy niezbędne procedury, dokumentację oraz rozwiązania techniczne zgodne z wymaganiami RODO.",
    },
    {
      number: 4,
      title: "Szkolenia",
      description:
        "Przeprowadzamy szkolenia dla pracowników i kadry zarządzającej, aby zapewnić odpowiednią świadomość i wiedzę dotyczącą RODO.",
    },
    {
      number: 5,
      title: "Stałe wsparcie",
      description:
        "Zapewniamy bieżące wsparcie, monitoring zgodności oraz aktualizację procesów w przypadku zmian w organizacji lub przepisach.",
    },
  ]

  return (
    <section className="py-20 bg-gray-50 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">Jak działamy</h2>
          <p className="text-lg max-w-3xl mx-auto">
            Nasze podejście opiera się na sprawdzonej metodologii, która gwarantuje skuteczne wdrożenie i utrzymanie
            zgodności z RODO.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              {/* Timeline connector */}
              {index < steps.length - 1 && (
                <div className="absolute left-8 top-14 bottom-0 w-0.5 bg-blue-200 ml-0.5 hidden md:block"></div>
              )}

              <div className="flex flex-col md:flex-row gap-8 mb-12">
                {/* Number circle */}
                <div className="flex-shrink-0 z-10">
                  <div className="w-16 h-16 rounded-full bg-blue-800 text-white flex items-center justify-center text-2xl font-bold shadow-lg">
                    {step.number}
                  </div>
                </div>

                {/* Content */}
                <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 md:p-8 flex-grow">
                  <div className="flex items-center mb-4">
                    <CheckCircle className="text-blue-800 mr-3 h-6 w-6" />
                    <h3 className="text-xl font-bold">{step.title}</h3>
                  </div>
                  <p className="text-gray-700">{step.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
