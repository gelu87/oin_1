import Link from "next/link"
import Image from "next/image"
import { Facebook, Linkedin, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          <div>
            <div className="flex items-center mb-4">
              <Image src="/oin_logo.png" alt="OIN Logo" width={50} height={50} className="mr-3" />
              <h3 className="text-xl font-bold">Biuro Doradczo-Usługowe "OIN"</h3>
            </div>
            <p className="text-gray-300 mb-6">
              Biuro Doradczo-Usługowe "OIN" to zespół specjalistów z ponad 20-letnim doświadczeniem w dziedzinie ochrony
              danych osobowych. Zapewniamy kompleksowe wsparcie w zakresie wdrożenia i utrzymania zgodności z RODO.
            </p>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-800 transition-colors duration-300"
              >
                <Facebook size={20} />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-800 transition-colors duration-300"
              >
                <Linkedin size={20} />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-800 transition-colors duration-300"
              >
                <Twitter size={20} />
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4 relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-12 after:h-0.5 after:bg-blue-500">
              Nasze usługi
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                  Audyt RODO
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                  Szkolenia z RODO
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                  Wdrożenie RODO
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                  Konsultacje
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                  Outsourcing IOD
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-300 hover:text-white transition-colors duration-300">
                  Relacje z UODO
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4 relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-12 after:h-0.5 after:bg-blue-500">
              Kontakt
            </h3>
            <p className="text-gray-300 mb-2">
              ul. Bezpieczna 123
              <br />
              00-001 Warszawa
            </p>
            <p className="text-gray-300 mb-2">Tel: +48 123 456 789</p>
            <p className="text-gray-300">Email: kontakt@rodoekspert.pl</p>
          </div>
        </div>

        <div className="text-center pt-8 border-t border-gray-800 text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} Biuro Doradczo-Usługowe "OIN". Wszystkie prawa zastrzeżone. |
          <Link href="#" className="hover:text-white ml-1">
            Polityka prywatności
          </Link>{" "}
          |
          <Link href="#" className="hover:text-white ml-1">
            Polityka cookies
          </Link>
        </div>
      </div>
    </footer>
  )
}
