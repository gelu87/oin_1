export default function Quote() {
  return (
    <div className="relative py-16 bg-blue-800 overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-32 h-32 bg-blue-700 opacity-30 rounded-full transform -translate-x-16 -translate-y-16"></div>
      <div className="absolute bottom-0 right-0 w-48 h-48 bg-blue-700 opacity-30 rounded-full transform translate-x-24 translate-y-24"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <svg className="w-12 h-12 mx-auto mb-4 text-blue-300" fill="currentColor" viewBox="0 0 24 24">
            <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
          </svg>
          <p className="text-2xl italic text-white font-light">"RODO to dla nas chleb powszedni"</p>
        </div>
      </div>
    </div>
  )
}
