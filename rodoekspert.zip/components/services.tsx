import { ServiceCard } from "./service-card"

export default function Services() {
  const services = [
    {
      id: 1,
      title: "Audyt RODO",
      description:
        "Dogłębnie analizujemy specyfikę Twojej firmy, aby dostosować wymogi RODO do Twoich indywidualnych potrzeb. Nie korzystamy z szablonów – precyzyjnie identyfikujemy obszary wymagające uwagi, abyś mógł spać spokojnie.",
      image: "/audyt_rodo_service.jpg",
    },
    {
      id: 2,
      title: "Szkolenia z RODO",
      description:
        "Tworzymy spersonalizowane programy szkoleniowe dopasowane do branży i wielkości Twojej firmy. Uczymy praktycznej ochrony danych z uwzględnieniem specyfiki Twojego biznesu, zapewniając pełne bezpieczeństwo informacji.",
      image: "/szkolenia_z_rodo_service.jpg",
    },
    {
      id: 3,
      title: "Wdrożenie RODO",
      description:
        "Kompleksowo analizujemy specyfikę Twojej działalności i dostosowujemy wszystkie wymogi RODO do unikalnych procesów w firmie. Każde rozwiązanie tworzymy indywidualnie, zapewniając pełną zgodność z przepisami, byś mógł spokojnie prowadzić biznes.",
      image: "/wdrozenia_rodo_service.jpg",
    },
    {
      id: 4,
      title: "Konsultacje",
      description:
        "Wsłuchujemy się w Twoje potrzeby i odpowiadamy na pytania dotyczące ochrony danych w kontekście specyfiki Twojego biznesu. Nasz zespół analizuje indywidualnie każdą sytuację, dzięki czemu możesz spać spokojnie.",
      image: "/konsultacje_service.jpg",
    },
    {
      id: 5,
      title: "Outsourcing IOD",
      description:
        "Nasz zespół pełni funkcję Twojego Inspektora Ochrony Danych, poznając dokładnie procedury i potrzeby Twojej firmy. Nie oferujemy uniwersalnych rozwiązań – dopasowujemy się do Ciebie, zapewniając pełne bezpieczeństwo danych.",
      image: "/iod_service.jpg",
    },
    {
      id: 6,
      title: "Relacje z UODO",
      description:
        "W przypadku kontroli analizujemy indywidualnie Twoją sytuację i reprezentujemy firmę przed UODO. Nie działamy szablonowo – poznajemy specyfikę Twojej branży, zapewniając spokój nawet w przypadku kontroli.",
      image: "/placeholder.svg?key=tfrm2",
    },
  ]

  return (
    <section id="services" className="py-20 bg-white relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-blue-800 mb-4">Jak możemy Ci pomóc?</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <ServiceCard
              key={service.id}
              title={service.title}
              description={service.description}
              imageUrl={service.image}
            />
          ))}
        </div>
      </div>
      <div className="section-divider"></div>
    </section>
  )
}
